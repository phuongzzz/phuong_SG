.. cloudify-cli documentation master file, created by
   sphinx-quickstart on Thu Jun 12 15:30:03 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to cloudify-openstack-plugin's documentation!
=====================================================

Contents:

.. toctree::
   :maxdepth: 2

.. automodule:: neutron_plugin.floatingip
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: neutron_plugin.network
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: neutron_plugin.port
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: neutron_plugin.router
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: neutron_plugin.security_group
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: neutron_plugin.subnet
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: nova_plugin.server
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: openstack_plugin_common.__init__
   :members:
   :undoc-members:
   :show-inheritance:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

